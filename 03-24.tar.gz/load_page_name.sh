hive -e "load data local inpath '/home/jipengzeng/weixin/liucheng/cn_method_name.txt' overwrite into table tmp.zjp_weixin_page_name"
