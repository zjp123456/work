hive -e "load data local inpath '/home/jipengzeng/weixin/liucheng/wx_cate_name.txt' overwrite into table tmp.zjp_wx_cate_name"
