hive -e "load data local inpath './wx_hierarchy_name.txt' overwrite into table tmp.zjp_new_wx_mainpage_hierarchy_name;"
